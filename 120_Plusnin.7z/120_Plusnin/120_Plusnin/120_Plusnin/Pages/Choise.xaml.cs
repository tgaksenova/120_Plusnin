﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace _120_Plusnin.Pages
{
    /// <summary>
    /// Логика взаимодействия для Choise.xaml
    /// </summary>
    public partial class Choise : Page
    {
        public Choise()
        {
            InitializeComponent();

        }
        private void Guest_Click(object sender, RoutedEventArgs e)
        {
            Main mainp = new Main();
            mainp.AddBut.Visibility = Visibility.Hidden;
            (App.Current.MainWindow as MainWindow).mainFrame.Navigate(mainp);
            
        }

        private void Auth_Click(object sender, RoutedEventArgs e)
        {
            (App.Current.MainWindow as MainWindow).mainFrame.Navigate(new Pages.Auth());
        }

        private void Reg_Click(object sender, RoutedEventArgs e)
        {
            (App.Current.MainWindow as MainWindow).mainFrame.Navigate(new Pages.Reg());
        }
    }
}
