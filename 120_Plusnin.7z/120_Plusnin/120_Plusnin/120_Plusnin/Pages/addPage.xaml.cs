﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace _120_Plusnin.Pages
{
    /// <summary>
    /// Логика взаимодействия для addPage.xaml
    /// </summary>
    public partial class addPage : Page
    {
        public addPage()
        {
            InitializeComponent();
            category.ItemsSource = App.categories.Select(x => x.category).ToList();
            oplat.ItemsSource = App.sposoboplats.Select(x => x.Type).ToList();
            dost.ItemsSource = App.typedosts.Select(x => x.Type).ToList();

        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            (App.Current.MainWindow as MainWindow).mainFrame.Navigate(new Main());
        }

        private void Add_Click(object sender, RoutedEventArgs e)
        {
            Random rnd = new Random();
            if ((!String.IsNullOrEmpty(Title.Text)) && category.SelectedValue != null && oplat.SelectedValue != null && dost.SelectedValue != null)
            {
                Entities entities = new Entities();
                entities.Obyav.Add(new Obyav()
                {
                    ID = rnd.Next(7, 100),
                    IDCategory = App.categories.Find(x => x.category == category.SelectedValue.ToString()).ID,
                    typeDost = App.typedosts.Find(x => x.Type == dost.SelectedValue.ToString()).ID,
                    ObyavName = Title.Text,
                    typeOplat = App.sposoboplats.Find(x => x.Type == oplat.SelectedValue.ToString()).ID,
                    IDSeller = App.sellerID,
                    publishDate = date.SelectedDate
                });
                entities.SaveChanges();
                entities = new Entities();
                App.obyav = entities.Obyav.ToList();
                (App.Current.MainWindow as MainWindow).mainFrame.Navigate(new Main());
            }

        }
    }
}
