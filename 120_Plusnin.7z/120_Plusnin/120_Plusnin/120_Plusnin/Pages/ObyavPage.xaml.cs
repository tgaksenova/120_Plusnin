﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace _120_Plusnin.Pages
{
    /// <summary>
    /// Логика взаимодействия для ObyavPage.xaml
    /// </summary>
    /// 
    //<Button Click="Button_Click" Margin="50,0,0,0" Height="auto" MinWidth="150" Content="Delete" FontSize="20" FontWeight="Bold" HorizontalAlignment="Left"></Button>
    public partial class ObyavPage : Page
    {
        public ObyavPage()
        {
            InitializeComponent();
            obyav.ItemsSource = App.obyav;
            CategoyCombo.ItemsSource = App.categories.Select(x => x.category).ToList();
            OplatCombo.ItemsSource = App.sposoboplats.Select(x => x.Type).ToList();
            SellerCombo.ItemsSource = App.sellers.Select(x => x.FIO).ToList();
            SposoCombo.ItemsSource = App.typedosts.Select(x => x.Type).ToList();

        }

        private void StackPanel_MouseDown(object sender, MouseButtonEventArgs e)
        {

        }

        private void Submit_Click(object sender, RoutedEventArgs e)
        {
            List<Obyav> obyavs = App.obyav;
            if (!String.IsNullOrEmpty(Search.Text))
            {
                obyavs = obyavs.Where(x => x.ObyavName.Contains(Search.Text)).ToList();
            }

            if (SellerCombo.SelectedValue != null)
            {
                obyavs = obyavs.Where(x => x.Seller.FIO == SellerCombo.SelectedValue.ToString()).ToList();
            }


            if (SposoCombo.SelectedValue != null)
            {
                obyavs = obyavs.Where(x => x.Dost.Type == SposoCombo.SelectedValue.ToString()).ToList();
            }



            if (OplatCombo.SelectedValue != null)
            {
                obyavs = obyavs.Where(x => x.Oplat.Type == OplatCombo.SelectedValue.ToString()).ToList();
            }


            if (CategoyCombo.SelectedValue != null)
            {
                obyavs = obyavs.Where(x => x.Categories.category == CategoyCombo.SelectedValue.ToString()).ToList();
            }



            obyav.ItemsSource = obyavs;
        }


        private void Deny_Click(object sender, RoutedEventArgs e)
        {
            Search.Text = "";
            SellerCombo.SelectedValue = null;
            SposoCombo.SelectedValue = null;
            OplatCombo.SelectedValue = null;
            CategoyCombo.SelectedValue = null;
            obyav.ItemsSource = App.obyav;

        }

    }
}
