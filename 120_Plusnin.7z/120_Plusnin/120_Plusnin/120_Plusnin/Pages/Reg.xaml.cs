﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace _120_Plusnin.Pages
{
    /// <summary>
    /// Логика взаимодействия для Reg.xaml
    /// </summary>
    public partial class Reg : Page
    {
        public Reg()
        {
            InitializeComponent();
            Region.ItemsSource = App.regions.Select(x => x.region1).ToList();
        }

        private void Auth_Click(object sender, RoutedEventArgs e)
        {
            bool isTrue = (!String.IsNullOrEmpty(Fio.Text)) && (!String.IsNullOrEmpty(Phone.Text)) && (!String.IsNullOrEmpty(Email.Text)) && (!String.IsNullOrEmpty(Adress.Text)) && (!String.IsNullOrEmpty(Login.Text)) && (!String.IsNullOrEmpty(Password.Text));
            if (isTrue)
            {
                Entities entities = new Entities();
                entities.Seller.Add(new Seller() { eMail = Email.Text, adress = Adress.Text, FIO = Fio.Text, Login = Login.Text, Passwor = Password.Text, phoneNumber = Phone.Text, region = App.regions.Find(x => x.region1 == Region.SelectedValue).ID });
                entities.SaveChanges();
                App.sellers = entities.Seller.ToList();
                (App.Current.MainWindow as MainWindow).mainFrame.Navigate(new Pages.Auth());
            }
        }

    private void Back_Click(object sender, RoutedEventArgs e)
        {
            (App.Current.MainWindow as MainWindow).mainFrame.Navigate(new Choise());
        }
    }
}
