﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace _120_Plusnin.Pages
{
    /// <summary>
    /// Логика взаимодействия для Auth.xaml
    /// </summary>
    public partial class Auth : Page
    {
        public Auth()
        {
            InitializeComponent();
        }

        private void Auth_Click(object sender, RoutedEventArgs e)
        {
            if ((!String.IsNullOrEmpty(Login.Text)) && (!String.IsNullOrEmpty(Password.Password)))
            {
                var isLog = App.sellers.Where(x => x.Login == Login.Text && x.Passwor == Password.Password).Count();
                if (isLog > 0)
                {
                    Main mainp = new Main(); 
                    App.sellerID = App.sellers.Where(x => x.Login == Login.Text && x.Passwor == Password.Password).ToList().First().ID;
                    mainp.AddBut.Visibility = Visibility.Visible;
                    (App.Current.MainWindow as MainWindow).mainFrame.Navigate(mainp);

                }
            }
        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            (App.Current.MainWindow as MainWindow).mainFrame.Navigate(new Choise());
        }

    }
}
