﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;

namespace _120_Plusnin
{
    /// <summary>
    /// Логика взаимодействия для App.xaml
    /// </summary>
    public partial class App : Application
    {
        public static bool isAuth = false;
        public static List<Obyav> obyav;
        public static List<Seller> sellers;
        public static List<Categories> categories;
        public static List<Region> regions;
        public static List<Oplat> sposoboplats;
        public static List<Dost> typedosts;

        public static bool IsAuth = false;
        public static int sellerID;
       

        public static void LoadDB()
        {
            Entities db = new Entities();
            obyav = db.Obyav.ToList();
            sellers = db.Seller.ToList();
            categories = db.Categories.ToList();
            regions = db.Region.ToList();
            sposoboplats = db.Oplat.ToList();
            typedosts = db.Dost.ToList();

        }
    }

    
}
